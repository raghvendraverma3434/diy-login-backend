INSERT INTO users (username, email, password_hash) VALUES
('admin', 'admin@example.com', '$2a$10$1f4WfQ2WZlKQZQp5sH6pZevhT..Xq8XgnzcbI7fBxPqNnmc1pQp2O'); -- password: Admin@123
